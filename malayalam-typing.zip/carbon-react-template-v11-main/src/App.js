import React from "react";
import IBMHeader from "./Header";

const App = () => {
  return (
    <div className="container">
      <IBMHeader />
      <div className="wrapper">
        <h5>Carbon Template</h5>
        
      </div>
    </div>
  );
}

export default App;
